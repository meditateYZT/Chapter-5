package com.bytedance.androidcamp.network.dou.api;

public interface IMiniDouyinService {
    // TODO 7: Define IMiniDouyinService
}
